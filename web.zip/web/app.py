import os
import sys
import cv2
import torch
import numpy as np
from flask import Flask, render_template, request, redirect, url_for, Response

# URL kamera HP (IP Webcam / DroidCam)
IP_WEBCAM_URL = 'http://192.168.137.21:4747/video'

# Tambahkan path YOLOv7 (naik 1 folder dari web/)
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from models.experimental import attempt_load
from utils.torch_utils import select_device
from utils.general import non_max_suppression, scale_coords
from utils.datasets import letterbox

# ---------------- Flask Setup ----------------
app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = os.path.join('web', 'static', 'uploads')

# ---------------- Load YOLOv7 ----------------
weights = os.path.join('runs', 'train', 'exp3', 'weights', 'best.pt')  # ganti exp kalau perlu
device = select_device('0')  # gunakan GPU 0, atau 'cpu' kalau tidak pakai GPU
model = attempt_load(weights, map_location=device)
model.eval()
stride = int(model.stride.max())
names = model.module.names if hasattr(model, 'module') else model.names


# ---------------- Fungsi Deteksi ----------------
def detect_image(img):
    img0 = img.copy()

    # letterbox biar rasio aspek tidak rusak
    img = letterbox(img0, 640, stride=stride, auto=True)[0]
    img = img[:, :, ::-1].transpose(2, 0, 1)  # BGR -> RGB, channel first
    img = np.ascontiguousarray(img)

    img = torch.from_numpy(img).to(device)
    img = img.float() / 255.0
    if img.ndimension() == 3:
        img = img.unsqueeze(0)

    with torch.no_grad():
        pred = model(img, augment=False)[0]
        pred = non_max_suppression(pred,
                                   conf_thres=0.5,
                                   iou_thres=0.45,
                                   agnostic=False)

    for det in pred:
        if len(det):
            det[:, :4] = scale_coords(img.shape[2:], det[:, :4], img0.shape).round()
            for *xyxy, conf, cls in reversed(det):
                label = f'{names[int(cls)]} {conf:.2f}'
                cv2.rectangle(
                    img0,
                    (int(xyxy[0]), int(xyxy[1])),
                    (int(xyxy[2]), int(xyxy[3])),
                    (0, 255, 0),
                    2
                )
                cv2.putText(
                    img0,
                    label,
                    (int(xyxy[0]), int(xyxy[1]) - 5),
                    cv2.FONT_HERSHEY_SIMPLEX,
                    0.6,
                    (0, 255, 0),
                    2
                )
    return img0


# ---------------- ROUTES ----------------
@app.route('/')
def index():
    return render_template('index.html')


# ---------- Upload & Deteksi Gambar ----------
@app.route('/upload_image', methods=['POST'])
def upload_image():
    file = request.files.get('file')
    if file is None or file.filename == '':
        return redirect(request.url)

    path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
    file.save(path)

    img = cv2.imread(path)
    result = detect_image(img)
    result_path = os.path.join(app.config['UPLOAD_FOLDER'], 'result_' + file.filename)
    cv2.imwrite(result_path, result)

    # kirim path relatif dari /static
    return render_template(
        'index.html',
        image_file='uploads/' + 'result_' + file.filename,
        video_filename=None
    )


# ---------- Upload & Deteksi Video (streaming, tanpa download) ----------
@app.route('/upload_video', methods=['POST'])
def upload_video():
    file = request.files.get('file')
    if file is None or file.filename == '':
        return redirect(request.url)

    filename = file.filename
    path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(path)

    # tampilkan player streaming di halaman utama
    return render_template('index.html',
                           video_filename=filename,
                           image_file=None)


def gen_video(path):
    cap = cv2.VideoCapture(path)
    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        result = detect_image(frame)
        ret, buffer = cv2.imencode('.jpg', result)
        if not ret:
            continue

        frame = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    cap.release()


@app.route('/stream_video/<filename>')
def stream_video(filename):
    video_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    return Response(
        gen_video(video_path),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )


# ---------- Realtime: pilih kamera (PC / HP) ----------
def gen_frames(source):
    """
    source:
      - int  -> index kamera (0 = webcam laptop)
      - str  -> URL IP camera (misal IP_WEBCAM_URL)
    """
    if isinstance(source, str):
        cap = cv2.VideoCapture(source)
    else:
        cap = cv2.VideoCapture(int(source))

    while cap.isOpened():
        success, frame = cap.read()
        if not success:
            break

        result = detect_image(frame)
        ret, buffer = cv2.imencode('.jpg', result)
        if not ret:
            continue

        frame = buffer.tobytes()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')
    cap.release()


# Realtime dari kamera laptop (default: index 0)
@app.route('/realtime_pc')
def realtime_pc():
    return Response(
        gen_frames(0),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )


# Realtime dari kamera HP (IP Webcam)
@app.route('/realtime_hp')
def realtime_hp():
    return Response(
        gen_frames(IP_WEBCAM_URL),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )


# Opsional: route generic dengan query ?src=
@app.route('/realtime')
def realtime():
    # ?src=pc  -> webcam 0
    # ?src=hp  -> IP webcam
    # ?src=1   -> webcam index 1
    src = request.args.get('src', 'pc')

    if src == 'hp':
        source = IP_WEBCAM_URL
    else:
        # kalau bukan 'hp', coba jadikan int (default 0)
        try:
            source = int(src)
        except ValueError:
            source = 0

    return Response(
        gen_frames(source),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )


# ---------------- Jalankan Flask ----------------
if __name__ == '__main__':
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(host='0.0.0.0', port=5000, debug=True)
